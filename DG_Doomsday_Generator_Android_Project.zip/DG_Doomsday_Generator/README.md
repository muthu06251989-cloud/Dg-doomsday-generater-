# DG – Doomsday Generator (Android starter project)

This is the first Android Studio project for DG, separate from DMG.

## Included in this starter
- DG home screen and feature cards
- Change Spot: demo counter capped at 48
- Photo into Video AI: demo counter capped at 25
- Songs & Tunes feature entry
- Special Effects feature entry
- No payment, subscription, premium tier, sign-up, or credit-card flow
- No runtime permissions requested in this starter

## Important: prototype, not a finished AI app
The buttons currently demonstrate the app flow and update local in-memory demo counters. They do **not** generate videos, songs, or effects yet. Real generation requires selecting and connecting AI providers, a secure backend, upload handling, moderation, and cost controls. "Free to users" does not mean the AI infrastructure has no operating cost.

The counters currently reset when the app process is restarted. Before release, persist limits securely and decide whether they are per device or per account. Do not rely on client-only counters to enforce production limits.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync and install the Android SDK platform/build tools requested by the IDE.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

This environment did not have Android SDK/Gradle installed, so an APK could not be compiled or tested here.

## Privacy
A responsible public app should provide an accessible privacy policy/notice explaining what data is collected, where media is processed, retention, and third-party AI providers. Request only permissions needed for a feature, at the time the user invokes it. This starter requests no media permissions.
