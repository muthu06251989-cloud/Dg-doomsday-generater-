package com.doomsdaygenerator.dg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090D1B)
private val Panel = Color(0xFF171D32)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DGApp() }
    }
}

@Composable
fun DGApp() {
    var changeSpotUsed by remember { mutableIntStateOf(0) }
    var photoVideoUsed by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf("Home") }
    var notice by remember { mutableStateOf("Welcome to DG. Your creative studio starts here.") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Violet,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Create", "Effects").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Home" -> Icons.Default.Home
                                        "Create" -> Icons.Default.AutoAwesome
                                        else -> Icons.Default.Bolt
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                indicatorColor = Violet.copy(alpha = .25f),
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .background(Brush.verticalGradient(listOf(Night, Color(0xFF111A35))))
                    .padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Spacer(Modifier.height(10.dp)) }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("DG", color = Cyan, fontSize = 34.sp, fontWeight = FontWeight.Black)
                            Text("DOOMSDAY GENERATOR", color = Color.White, fontSize = 13.sp,
                                fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                        Surface(color = Color(0xFF123B38), shape = RoundedCornerShape(50)) {
                            Text("100% FREE", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                color = Color(0xFF6EE7B7), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Create beyond limits.", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("Turn your ideas into cinematic moments.", color = Color.LightGray)
                            Spacer(Modifier.height(12.dp))
                            Text("No subscription • No premium tier • No credit card",
                                color = Cyan, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text(if (selected == "Home") "YOUR CREATIVE TOOLS" else selected.uppercase(),
                        color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
                item {
                    FeatureCard("Change Spot", "Replace a video's location using a text prompt.",
                        "48 free generations", Icons.Default.LocationOn,
                        "${48 - changeSpotUsed} / 48 remaining") {
                        if (changeSpotUsed < 48) {
                            changeSpotUsed++
                            notice = "Demo action recorded. Connect an AI video service to render the edited video."
                        } else notice = "Your 48 Change Spot demo generations have been used."
                    }
                }
                item {
                    FeatureCard("Photo into Video AI", "Animate a photo with movement described in your prompt.",
                        "25 free generations", Icons.Default.MotionPhotosOn,
                        "${25 - photoVideoUsed} / 25 remaining") {
                        if (photoVideoUsed < 25) {
                            photoVideoUsed++
                            notice = "Demo action recorded. Connect an image-to-video AI service to generate a video."
                        } else notice = "Your 25 Photo into Video demo generations have been used."
                    }
                }
                item {
                    FeatureCard("Songs & Tunes", "Create original songs, instrumentals and background music.",
                        "Free feature", Icons.Default.MusicNote, "AI service connection needed") {
                        notice = "Song and tune creation will be enabled after connecting an audio-generation service."
                    }
                }
                item {
                    FeatureCard("Special Effects", "Explore cinematic effects, energy, lightning, fire and sci-fi looks.",
                        "Free feature", Icons.Default.Bolt, "AI / effects engine needed") {
                        notice = "Special effects workspace selected. Effects engine connection is needed for rendering."
                    }
                }
                item {
                    Surface(color = Color(0xFF202A46), shape = RoundedCornerShape(14.dp)) {
                        Text(notice, modifier = Modifier.padding(14.dp), color = Color.White, fontSize = 13.sp)
                    }
                }
                item {
                    Text("Privacy matters", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("This starter app does not request photo, video, microphone, location or contacts permissions. Before launch, add a clear privacy notice describing any AI services and data handling.",
                        color = Color.LightGray, fontSize = 12.sp)
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String, description: String, tag: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: String, onClick: () -> Unit
) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Violet.copy(alpha = .2f), shape = RoundedCornerShape(12.dp)) {
                    Icon(icon, contentDescription = null, tint = Cyan,
                        modifier = Modifier.padding(11.dp).size(25.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(tag, color = Cyan, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(description, color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(count, color = Color(0xFFB8C4E5), fontSize = 11.sp,
                    modifier = Modifier.weight(1f))
                Button(onClick = onClick, colors = ButtonDefaults.buttonColors(
                    containerColor = Violet, contentColor = Color.White
                )) { Text("Open") }
            }
        }
    }
}
